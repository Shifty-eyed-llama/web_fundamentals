$(document).ready(function(){
    $('#cat img').click(function(){
        var temp = $(this).attr('src');
        $(this).attr('src', $(this).attr('data-alt-src'));
        $(this).attr('data-alt-src', temp)
    })
    // $('#cat img').click(function(){
    //     $(this).attr('data-alt-src', $(this).attr('src'));
    // })
    // $('#cat img').on('click', ['src'], [function()]{
    //     $(this).attr('src', $(this).attr('data-alt-src'))
    // });
    // $('#cat img').on('click', 'data-alt-src', function(){
    //     $(this).attr('data-alt-src', $(this).attr('src'))
    // })
})